import gtts
import playsound
import time
import random
import os
from english_words import english_words_set
import multiprocessing
import tkinter

#try to spell these words: conscience prohibit temperature together genuine obedience vegetable september lightning president guilty property surprise imagination union tomatoes heroes reporter satisfy selector release research respectable wardrobe attention criminal league unnatural important authority insincere journey revenge consumer fashion journalist hospital sprain forgiven referee equipment introduce programme generous patience audience explosion distinguish illustration fierce




#background music
def background_music():
        playsound.playsound('SFX/bgMusic.mp3')

if __name__ == '__main__': 
    #declares important variables
    score = 0

    incorrect = 0

    start = False

    print('\nWelcome To The Spelling Checker!\nType *again if you didn\'t hear a word\nType *quit to quit\n')

    #asks for gamemode     
    gamemode = input('\nPlease enter your desired gamemode (20 right, endless, hardcore, spelling bee or test): ')
    


    

    #starts background music
    bgM = multiprocessing.Process(target=background_music)
    bgM.start()


    #asks for list of words if chosen such gamemode and changing other features for each of them


    #20 right: User has to answer 20 questions right to win, however if user answers 3 questions wrong, they lose
    if gamemode == '20 right' or gamemode == 'test':
        words = input('\nPlease enter your words(seperated by Spaces): ').split(' ')
        
        start = True
    
    if gamemode == 'spelling bee':
        words = list(english_words_set)
        start = True

    if gamemode == 'hardcore':
        words = input('\nPlease enter your words(seperated by Spaces): ').split(' ')
        incorrect = 2
        start = True

    #main loop for gamemodes 20 right, spelling bee and hardcore
    if gamemode == '20 right' or gamemode == 'spelling bee' or gamemode == 'hardcore':
        while start:
            
            #showing info
            print('\nScore: {0}\n'.format(score))
            print('\nAmount of answers you got wrong (3 wrong = Game Over): {0} answer/s wrong/s\n'.format(incorrect))

            #picking random word
            randwordindex = random.randint(0,(len(words) - 1))
            gttsWord = gtts.gTTS('Spell {0}'.format(words[randwordindex]))
            
            #save mp3 file of the TTS word
            if os.path.exists('SFX/word.mp3'):
                os.remove('SFX/word.mp3')
                gttsWord.save('SFX/word.mp3')
            else:
                gttsWord.save('SFX/word.mp3')
                
            #asks for spelling
            time.sleep(0.5)
            playsound.playsound('SFX/word.mp3')
            answer = input('Enter Your Spelling: ')

            #checks if right or wrong
                        
            while answer == '*again':
                #if user didnt hear it
                playsound.playsound('SFX/word.mp3')
                answer = input('\nEnter Your Spelling: ')


            #if user wants to quit
            if answer == '*quit':
                
                
                quit = input('\nAre You sure you would like to quit?: ')

                if quit == 'Yes' or quit == 'yes' or quit == 'yep' or quit == 'ya':
                
                    print ('\n\n\nGame Over!\n\n\n')
                    bgM.terminate()
                    playsound.playsound('SFX/GameOver.mp3')
                    playsound.playsound('SFX/gameOverVoice.wav')
                    break

                else:
                    playsound.playsound('word.mp3')
                    answer = input('\nEnter Your Spelling: ')


            #checking if correct and saying
            if answer == words[randwordindex]:
                print('\nYour answer was correct! Good job!\n ')
                
                playsound.playsound('SFX/Right-Ding.mp3')
                playsound.playsound('SFX/Right.mp3')

                score += 1

            #checking if incorrect and saying
            else:
                print('\nOops, You got the answer wrong! The correct spelling was {0}'.format(str(list(words[randwordindex]))))   
                
                gttsWrong = gtts.gTTS('Oops, You got the answer wrong! The correct spelling was {0}'.format(str(list(words[randwordindex]))))

                if os.path.exists('SFX/wrong.mp3'):
                    os.remove('SFX/wrong.mp3')
                    gttsWrong.save('SFX/wrong.mp3')
                else:
                    gttsWrong.save('SFX/wrong.mp3')
                

                playsound.playsound('SFX/incorrect_sfx.mp3')
                playsound.playsound('SFX/wrong.mp3')  
                
                incorrect += 1
                score -= 1
            

            #Won or Loss

            if score >= 20:
                print('\n\n\nYou Won!\n\n\n')
                bgM.terminate()
                playsound.playsound('SFX/Win_sfx.mp3')
                playsound.playsound('SFX/Win_Voice.mp3')
                break
            if incorrect >= 3:     
                print ('\n\n\nGame Over!\n\n\n')
                bgM.terminate()
                playsound.playsound('SFX/GameOver.mp3')
                playsound.playsound('SFX/gameOverVoice.wav')
                break

    
      #The Next two loops have pretty much the same logic, but with their own twists  
        
    if gamemode == 'endless':
        
        allOrCustom = input('\nWould you like to create your own list of words to spell or would you like to spell any word in english(answer all or custom):')

        if allOrCustom == 'custom':
            words = input('\nPlease enter your words(seperated by Spaces):').split(' ')
    
        if allOrCustom == 'all':
            words = list(english_words_set)

        while True:

            print('\nScore: {0}\n'.format(score))
            print('\nAmount of answers you got wrong: {0}'.format(incorrect))
            #picking random word
            randwordindex = random.randint(0,(len(words) - 1))
            gttsWord = gtts.gTTS('Spell {0}'.format(words[randwordindex]))
            
            if os.path.exists('SFX/word.mp3'):
                os.remove('SFX/word.mp3')
                gttsWord.save('SFX/word.mp3')
            else:
                gttsWord.save('SFX/word.mp3')
                

            time.sleep(0.5)
            playsound.playsound('SFX/word.mp3')
            
            #checks if right or wrong
            

            answer = input('\nEnter Your Spelling: ')
            

            while answer == '*again':
                playsound.playsound('SFX/word.mp3')
                answer = input('\nEnter Your Spelling: ')

            if answer == '*quit':
                
                
                quit = input('Are You sure you would like to quit?: ')

                if quit == 'Yes' or quit == 'yes' or quit == 'yep' or quit == 'ya':
                
                    print ('\n\n\nGame Over!\n\n\n')
                    bgM.terminate()
                    playsound.playsound('SFX/GameOver.mp3')
                    playsound.playsound('SFX/gameOverVoice.wav')
                    break


            if answer == words[randwordindex]:
                print('\nYour answer was correct! Good job!\n ')
                
                playsound.playsound('SFX/Right-Ding.mp3')
                playsound.playsound('SFX/Right.mp3')

                score += 1
            else:

                print('\nOops, You got the answer wrong! The correct spelling was {0}'.format(str(list(words[randwordindex]))))   
                
                gttsWrong = gtts.gTTS('Oops, You got the answer wrong! The correct spelling was {0}'.format(str(list(words[randwordindex]))))

                if os.path.exists('SFX/wrong.mp3'):
                    os.remove('SFX/wrong.mp3')
                    gttsWrong.save('SFX/wrong.mp3')
                else:
                    gttsWrong.save('SFX/wrong.mp3')
                

                playsound.playsound('SFX/incorrect_sfx.mp3')
                playsound.playsound('SFX/wrong.mp3')  
                
                incorrect += 1
                score -= 1
            

            #Won or Loss

            if score >= 20:
                print('\n\n\nYou Won!\n\n\n')
                bgM.terminate()
                playsound.playsound('SFX/Win_sfx.mp3')
                playsound.playsound('SFX/Win_Voice.mp3')

                break
            if incorrect >= 3:     
                print ('\n\n\nGame Over!\n\n\n')
                bgM.terminate()
                playsound.playsound('SFX/GameOver.mp3')
                playsound.playsound('SFX/gameOverVoice.wav')
                break

    if gamemode == 'test':

        if os.path.exists('report.txt'):
            os.remove('report.txt')
            

        report = open('report.txt','w+')
        report.write("**This Report was Auto-Generated By a Computer**\n\n")

        name = input('\nPlease Enter your first name:')
        report.write('Test Report for {0}\n\n'.format(name))
        report.write('Words Given by User: {0} \n\n'.format(str(words)))

        for i in range(0,20):      

            
            
            

            #picking random word
            randwordindex = random.randint(0,(len(words) - 1))
            gttsWord = gtts.gTTS('\nSpell {0}'.format(words[randwordindex]))
            report.write('Asked for spelling of the word {0}.\n'.format(words[randwordindex]))



            
            if os.path.exists('SFX/word.mp3'):
                os.remove('SFX/word.mp3')
                gttsWord.save('SFX/word.mp3')
            else:
                gttsWord.save('SFX/word.mp3')
                

            time.sleep(0.5)
            playsound.playsound('SFX/word.mp3')
            
            #checks if right or wrong
            

            answer = input('\nEnter Your Spelling: ')

            while answer == '*again':
                playsound.playsound('SFX/word.mp3')
                answer = input('\nEnter Your Spelling: ')

            if answer == '*quit':
                
                
                quit = input('\nAre You sure you would like to quit?: ')

                if quit == 'Yes' or quit == 'yes' or quit == 'yep' or quit == 'ya':
                
                    print ('\n\n\nGame Over!\n\n\n')
                    bgM.terminate()
                    playsound.playsound('SFX/GameOver.mp3')
                    playsound.playsound('SFX/gameOverVoice.wav')
                    break

                else:
                    playsound.playsound('SFX/word.mp3')
                    answer = input('\nEnter Your Spelling: ')

            report.write('Answer Given: {0}\n'.format(answer))



            if answer == words[randwordindex]:
                
                report.write('Result: Correct.\n\n')

                score += 1
            else:
                
                report.write('Result: Incorrect.\n\n') 
                
                
        report.write('\n\nScore: {0}/20 or {1}%.'.format(score,(score * 5)))
        print('\nYour Results have been recorded. Please check the "report.txt" file in this folder for your results')

        report.close()